---
name: Design fix
about: Suggest an idea for design and ui
title: ''
labels: design fix
assignees: ''

---

**Is your suggestion related to a problem? Please describe.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the design/style you'd like**
A clear and concise description of what you want to happen.
Design images needed to clearly understand

**Additional context**
Add any other context or screenshots about the design suggestion here.
