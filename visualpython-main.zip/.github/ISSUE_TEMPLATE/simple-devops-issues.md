---
name: simple devops issues
about: issues with simple changes
title: ''
labels: small change
assignees: minjk-bl

---

### TO-BE
1.  


--------------------------------

### AS-IS (Optional)
1.
